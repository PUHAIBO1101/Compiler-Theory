#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

using namespace std;

bool isAlpha(char t) {
    return (t >= 'a' && t <= 'z') || (t >= 'A' && t <= 'Z');
}

bool isDigit(char t) {
    return (t >= '0' && t <= '9');
}

const unordered_map<string, string> keywords = {
    {"if", "IF"},
    {"then", "THEN"},
    {"else", "ELSE"},
    {"while", "WHILE"},
    {"do", "DO"},
    {"int", "INT"}
};

const unordered_map<char, string> operators = {
    {'=', "EQ"},
    {'>', "GT"},
    {'<', "LT"},
    {'!', "NOT"},
    {'+', "ADD"},
    {'-', "SUB"},
    {'*', "MUL"},
    {'/', "DIV"}
};

const unordered_map<char, string> separators = {
    {'\'', "QUO"},
    {'(', "LP"},
    {')', "RP"},
    {';', "SEMI"}
};

void processToken(string& token, ofstream& tokenFile, ofstream& signalFile, int& posToken, int& posSignal) {
    if (keywords.find(token) != keywords.end()) {
        signalFile << token << "\t\tchar\t\tKeyword\t\t" << keywords.at(token) << endl;
        tokenFile << "Keyword\t\t" << keywords.at(token) << endl;
    } else {
        signalFile << token << "\t\tchar\t\tid\t\t" << token << endl;
        tokenFile << "id\t\t" << token << endl;
    }
    posSignal++;
    posToken++;
    token.clear();
}

void processChar(char c, string& token, ofstream& tokenFile, ofstream& signalFile, int& posToken, int& posSignal) {
    if (!token.empty()) {
        processToken(token, tokenFile, signalFile, posToken, posSignal);
    }
    string lexeme(1, c);
    if (operators.find(c) != operators.end()) {
        signalFile << lexeme << "\t\tchar\t\tOP\t\t" << operators.at(c) << endl;
        tokenFile << "OP\t\t" << operators.at(c) << endl;
    } else if (separators.find(c) != separators.end()) {
        signalFile << lexeme << "\t\tchar\t\tSEP\t\t" << separators.at(c) << endl;
        tokenFile << "SEP\t\t" << separators.at(c) << endl;
    }
    posSignal++;
    posToken++;
}

int main() {
    ifstream inputFile("input.txt");
    ofstream signalFile("signal_table.txt"), tokenFile("token.txt");

    string str, token;
    int posToken = 0, posSignal = 0;

    while (getline(inputFile, str)) {
        for (char c : str) {
            if (isAlpha(c) || isDigit(c)) {
                token += c;
            } else {
                processChar(c, token, tokenFile, signalFile, posToken, posSignal);
            }
        }
        if (!token.empty()) {
            processToken(token, tokenFile, signalFile, posToken, posSignal);
        }
    }

    inputFile.close();
    signalFile.close();
    tokenFile.close();

    return 0;
}
