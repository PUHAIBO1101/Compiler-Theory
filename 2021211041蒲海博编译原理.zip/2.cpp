#include<iostream>
#include<fstream>
#include<cstring>
#include<vector>
#include<stack>
using namespace std;

//-------------------------------------词法分析部分
string token="";

bool isAlpha(char t){
	if(t>='a'&&t<='z')
		return true;
	else if(t>='A'&&t<='Z')
		return true;
	return false;
}

bool isDigit(char t){
	if(t>='0'&&t<='9')
		return true;
	return false;
}

string isKeyword(string str,int head,int len){
	if(str.substr(head,len)=="if") return "f";
	else if(str.substr(head,len)=="else") return "e";
	else if(str.substr(head,len)=="while") return "w";
	else if(str.substr(head,len)=="int") return "i";
	return "-1";
}

string isOp(char t1,char t2){
	if(t1=='='&&t2=='=') return "#";
	else if(t1=='+') return string(1,t1);
	else if(t1=='-') return string(1,t1);
	else if(t1=='*') return string(1,t1);
	else if(t1=='/') return string(1,t1);
	else if(t1=='=') return string(1,t1);
	else if(t1=='>') return string(1,t1);
	else if(t1=='<') return string(1,t1);
	return "-1";
}

string isSep(char t){
	if(t=='(') return string(1,t);
	else if(t==')') return string(1,t);
	else if(t==';') return string(1,t);
	return "-1";
}

void read_code(){
	token="";//清空

	ifstream input_f;
	input_f.open("input_code.txt",ios::out);
	string str="";//代码内容

	while(!input_f.eof()){
		char s;
		input_f.get(s);
		str+=s;
	}
	input_f.close();
	str=str.substr(0,str.length()-1);
	int j=0,len=0;//当前单词的起始位置和长度
	while(j<str.length()){
		len=0;
		if(isDigit(str[j])){//整形
			while(isDigit(str[j+len]))	len++;
   			token+="n";
            j=j+len;
		}
		else if(isAlpha(str[j])){
			while(isDigit(str[j+len])||isAlpha(str[j+len]))	len++;
			if(isKeyword(str,j,len)!="-1"){//关键字
				token+=isKeyword(str,j,len);
	            j=j+len;
			}
			else{//标识符
				token+="d";
	            j=j+len;
			}
		}
		else if(isOp(str[j],str[j+1])!="-1"){//运算符
			string ans=isOp(str[j],str[j+1]);
			if(ans=="#"){
				token+=ans;
				j+=2;
			}
			else if(ans!="-1"){
				token+=ans;
				j++;
			}
		}
		else if(isSep(str[j])!="-1"){//分隔符
			string ans=isSep(str[j]);
			token+=ans;
			j++;
		}
		else if(str[j]==' '||str[j]=='\n'||str[j]=='	'){//跳过空格、换行、table
			j++;
		}
		else{//错误输入
			cout<<"a error: "<<str[j]<<"  in  "<<j<<endl;
			j++;
		}
	}
	ofstream token_f;
	token_f.open("token.txt",ios::out);
	token_f<<token;
	token_f.close();
	return ;
}
//--------------------------------------------------------------------------------------------以上是词法分析
vector<string> prod;//产生式
vector< vector<string> > ItemSet;//项集
int go[999][30]={0};
char ACTION[999][30]={0};
int GOTO[999][30]={0};
string map_char="BPDSLCEFTd;@i=f()ew><#+-*/n$";//字符到数字的映射
vector<string> first;//first集
vector<string> follow;//follow集
int gotfirst[30]={0};//已生成 first集
int gotfollow[30]={0};
int have_empty[30]={0};//是否能推出空字符

void read_gramma();//读入产生式
void make_ItemSet();//初始化项集
void closuer(vector<string>& );//生成 CLOSUER
char find_next_char(string );//找到项目中 . 后的字符
void add2vec(vector<string>& ,string );//加入容器
void sta_out(vector<string> ,int ,ofstream& );//生成离开每个状态的边( go[][]数组 )
string p_next(string );//将项目中的 . 后移一位
int exist_status(vector<string> );//检查项集族中是否已存在这个状态
bool eqVec(vector<string> ,vector<string> );//判断两容器是否相等
int char2int(char );//字符与数字的对应关系
void make_first();//生成 first集
void getfirst(int );//dfs生成 first
void make_follow();//生成 follow集
void getfollow(int );//dfs生成 follow
char char_in_prod(char ,int );//查找某字符在产生式中的位置
void make_analyze_table();//建立分析表
int locat_follow(char );//找到某字符的 follow集
int prod_num(string );//查找某字符串在产生式中的位置
void analyze();//开始分析
void show_stacks(ofstream& ,stack<int> ,stack<char> );//输出两个栈的当前内容

void read_gramma(){
	ifstream gramma_f("input_gramma.txt",ios::in);
	string gramma;
	while(!gramma_f.eof()){
		getline(gramma_f,gramma);
		prod.push_back(gramma);
	}
	for(int i=0;i<prod.size();++i){
		//cout<<prod[i]<<endl;
	}
	gramma_f.close();
	return ;
}

void make_ItemSet(){
	ofstream itemset_f("项集.txt",ios::out);
	vector<string> status_now;
	status_now.push_back("B|.P");//初始项
	closuer(status_now);
	ItemSet.push_back(status_now);
	for(int i=0;i<ItemSet.size();++i){
		itemset_f<<"-------status "<<i<<"---------------\n";
		for(int j=0;j<ItemSet[i].size();++j){
			itemset_f<<ItemSet[i][j]<<endl;
		}
		itemset_f<<"状态转移：\n";
		sta_out(ItemSet[i],i,itemset_f);
	}
	itemset_f.close();
	return ;
}

void closuer(vector<string> &status_now){
	for(int i=0;i<status_now.size();++i){
		char next_char=find_next_char(status_now[i]);//.后的字符
		if(next_char!=-1&&next_char!=0){
			for(int k=0;k<prod.size();++k){
				if(prod[k][0]==next_char){
					string t="";
					t+=prod[k].substr(0,3);
					t+=".";
					t+=prod[k].substr(3);
					add2vec(status_now,t);
				}
			}
		}
	}
	return ;
}

char find_next_char(string t){
	for(int i=0;i<t.size();++i){
		if(t[i]=='.'&&t[i+1]=='@') return 0;
		if(t[i]=='.'&&i!=t.size()-1){
			return t[i+1];
		}
	}
	return -1;
}

void add2vec(vector<string> &status_now,string t){
	for(int i=0;i<status_now.size();++i){
		if(status_now[i]==t)
			return ;
	}
	status_now.push_back(t);
	return ;
}

void sta_out(vector<string> itemset_i,int i,ofstream &itemset_f){
	while(itemset_i.size()){
		vector<string> new_status;
		char next_char=find_next_char(itemset_i[0]);
		if(next_char==-1||next_char==0){
			itemset_i.erase(itemset_i.begin());
			continue;
		}
		for(int j=0;j<itemset_i.size();++j){
			if(find_next_char(itemset_i[j])==next_char){
				new_status.push_back( p_next(itemset_i[j]) );
                itemset_i.erase(itemset_i.begin()+j);
                j--;
			}
		}
		closuer(new_status);
		int pos=exist_status(new_status);
		if(pos!=-1){
			go[i][char2int(next_char)]=pos;
			itemset_f<<i<<" : "<<next_char<<" -> "<<pos<<endl;
		}
		else{
			ItemSet.push_back(new_status);
			go[i][char2int(next_char)]=ItemSet.size()-1;
			itemset_f<<i<<" : "<<next_char<<" -> "<<ItemSet.size()-1<<endl;
		}
	}
	return ;
}

string p_next(string t){
	string ans="";
	int pos;
	for(int i=0;i<t.size();++i){
		if(t[i]=='.') pos=i;
	}
	ans+=t.substr(0,pos);
	ans+=t.substr(pos+1,1);
	ans+=".";
	ans+=t.substr(pos+2);
	return ans;
}

int exist_status(vector<string> t){
	for(int i=0;i<ItemSet.size();++i){
		if(eqVec(ItemSet[i],t)==true) return i;
	}
	return -1;
}

bool eqVec(vector<string> t1,vector<string> t2){
	if(t1.size()!=t2.size()) return false;
	for(int i=0;i<t1.size();++i){
		if(t1[i]!=t2[i]) return false;
	}
	return true;
}

int char2int(char c){
	for(int i=0;i<map_char.size();++i){
		if(map_char[i]==c) return i;
	}
	return -1;
}

void make_first(){
	for(int i=0;i<map_char.size();++i){
		string t="";
		t+=map_char[i];
		if(map_char[i]<'A' || map_char[i]>'Z'){//终结符
			t+=map_char[i];
			gotfirst[i]=1;
		}
		first.push_back(t);
	}
	for(int i=0;i<map_char.size();++i){
		if(gotfirst[i]==1) continue;
		getfirst(i);//dfs产生 first集
	}
	ofstream first_f("first.txt",ios::out);
	for(int i=0;i<first.size();++i){
		first_f<<first[i]<<endl;
	}
	first_f.close();
	return ;
}

void getfirst(int k){
	gotfirst[k]=1;
	for(int i=0;i<prod.size();++i){
		if(prod[i][0]!=map_char[k] || prod[i][3]==prod[i][0]) continue;
		char first_char=prod[i][3];//推出的第一个字符
		if(first_char<'A' || first_char>'Z'){//终结符
			if(first_char=='@'){
				have_empty[ char2int(map_char[k]) ]=1;
				continue;
			}
			first[k]+=first_char;
		}
		else{
			if(gotfirst[char2int(first_char)]==1) continue;
			getfirst( char2int(first_char) );
			first[k]+=first[ char2int(first_char) ].substr(1);
			int p=0;//此后 p个非终结符都能推出空字符
			while( have_empty[char2int(first_char)]==1 ){
				if( (p+3)==(prod[i].size()-1) ){//已经是最后一个了
					first[k]+='@';
					break;
				}
				p++;
				first_char=prod[i][3+p];
				getfirst( char2int(first_char) );
				first[k]+=first[ char2int(first_char) ].substr(1);
			}
		}
	}
	return ;
}

void make_follow(){
	for(int i=0;i<map_char.size();++i){
		if(map_char[i]<'A'||map_char[i]>'Z') continue;
		string t="";
		t+=map_char[i];
		if(i==0) t+="$";
		follow.push_back(t);
	}
	for(int i=0;i<map_char.size();++i){
		if(map_char[i]<'A'||map_char[i]>'Z') continue;
		if(gotfollow[i]==0) getfollow(i);
	}
	ofstream follow_f("follow.txt",ios::out);
	for(int i=0;i<follow.size();++i){
		follow_f<<follow[i]<<endl;
	}
	follow_f.close();
	return ;
}

void getfollow(int k){
	gotfollow[k]=1;
	for(int i=0;i<prod.size();++i){
		char c=char_in_prod(map_char[k],i);
		if(c==-1) continue;
		else if(c==0){//右边没了
			if(gotfollow[char2int(prod[i][0])]==0)
				getfollow(char2int(prod[i][0]));
			follow[k]+=follow[ char2int(prod[i][0]) ].substr(1);
		}
		else if(c<'A' || c>'Z'){//终结符
			if(c!='@') follow[k]+=c;
		}
		else if(c>='A' && c<='Z'){
			follow[k]+=first[char2int(c)].substr(1);
		}
	}
	return ;
}

char char_in_prod(char c,int i){
	for(int j=3;j<prod[i].size();++j){
		if(prod[i][j]==c){
			if(j==prod[i].size()-1) return 0;
			else return prod[i][j+1];
		}
	}
	return -1;
}

void make_analyze_table(){
	for(int i=0;i<ItemSet.size();++i){
		for(int j=0;j<ItemSet[i].size();++j){
			int pos=ItemSet[i][j].find('.');
			if(find_next_char(ItemSet[i][j])==-1||find_next_char(ItemSet[i][j])==0){//.在最右边
				if(ItemSet[i][j][0]=='B')//接受
					ACTION[i][char2int('$')]='a';
				else{//归约
					int loca=locat_follow(ItemSet[i][j][0]);//找到 follow集
					for(int k=1;k<follow[loca].size();++k){
						ACTION[i][char2int(follow[loca][k])]='r';//reduce 归约
						GOTO[i][char2int(follow[loca][k])]=prod_num(ItemSet[i][j].substr(0,ItemSet[i][j].size()-1));
					}
				}
			}
			else if(find_next_char(ItemSet[i][j])!=0){
				if(ItemSet[i][j][pos+1]>='A'&&ItemSet[i][j][pos+1]<='Z'){//非终结符
					ACTION[i][char2int(ItemSet[i][j][pos+1])]='g';//goto
					GOTO[i][char2int(ItemSet[i][j][pos+1])]=go[i][char2int(ItemSet[i][j][pos+1])];
				}
				else{//终结符
					ACTION[i][char2int(ItemSet[i][j][pos+1])]='m';//move in
					GOTO[i][char2int(ItemSet[i][j][pos+1])]=go[i][char2int(ItemSet[i][j][pos+1])];
				}
			}
		}
	}
	ofstream ACTION_f("ACTION.txt",ios::out);
	ofstream GOTO_f("GOTO.txt",ios::out);
	ACTION_f<<map_char<<endl;
	for(int i=0;i<ItemSet.size();++i){
		for(int j=0;j<30;++j){
			ACTION_f<<ACTION[i][j];
			GOTO_f<<GOTO[i][j];
		}
		ACTION_f<<endl;
		GOTO_f<<endl;
	}
	ACTION_f.close();
	GOTO_f.close();
	return ;
}

int locat_follow(char c){
	for(int i=0;i<follow.size();++i){
		if(follow[i][0]==c) return i;
	}
	return -1;
}

int prod_num(string t){
	for(int i=0;i<prod.size();++i){
		if(prod[i]==t) return i;
	}
	return -1;
}

void analyze(){
	ofstream analyze_f("analyze.txt",ios::out);
	stack<int> status_stack;//状态栈
	stack<char> chara_stack;//符号栈
	while(!status_stack.empty()) status_stack.pop();
	while(!chara_stack.empty()) chara_stack.pop();
	token+="$";
	status_stack.push(0);
	int pos=0;//输入串中的位置
	while(true){
		int status=status_stack.top();
		if(ACTION[status][ char2int(token[pos]) ]=='m'){//移入
			cout<<"移入： "<<token[pos]<<"  位置:  "<<pos<<endl;
			analyze_f<<"移入： "<<token[pos]<<"  位置:  "<<pos<<endl;
			chara_stack.push(token[pos]);
			status_stack.push(GOTO[status][ char2int(token[pos]) ]);
			show_stacks(analyze_f,status_stack,chara_stack);
			pos++;
		}
		else if(ACTION[status][ char2int(token[pos]) ]=='r'){//归约
			string prod_used=prod[ GOTO[status][ char2int(token[pos]) ] ];
			for(int i=0;i<prod_used.size()-3;++i){
				status_stack.pop();
				chara_stack.pop();
			}
			chara_stack.push(prod_used[0]);
			status_stack.push( GOTO[status_stack.top()][ char2int(prod_used[0]) ] );
			cout<<"归约： "<<prod_used<<endl;
			analyze_f<<"归约： "<<prod_used<<endl;
			show_stacks(analyze_f,status_stack,chara_stack);
		}
		else if(ACTION[status][ char2int(token[pos]) ]=='a'){//接受
			cout<<"分析完成，可以接受"<<endl;
			analyze_f<<"分析完成，可以接受"<<endl;
			show_stacks(analyze_f,status_stack,chara_stack);
			break;
		}
		else {
			cout<<"a error: "<<token[pos]<<endl;
			analyze_f<<"a error: "<<token[pos]<<endl;
			show_stacks(analyze_f,status_stack,chara_stack);
			pos++;
			break;
		}
	}
	analyze_f.close();
	return ;
}

void show_stacks(ofstream& analyze_f,stack<int> status_stack,stack<char> chara_stack){
	while(!status_stack.empty()&&!chara_stack.empty()){
		cout<<"状态栈："<<status_stack.top()<<"    "<<"符号栈："<<chara_stack.top()<<endl;
		analyze_f<<"状态栈："<<status_stack.top()<<"    "<<"符号栈："<<chara_stack.top()<<endl;
		status_stack.pop();
		chara_stack.pop();
	}
	return;
}

int main(){

	read_gramma();//读入产生式
	make_ItemSet();//构造项集
	make_first();//求 first集
	make_follow();//求 follow集
	read_code();//生成 token
	make_analyze_table();//建立分析表
	analyze();//分析器
	return 0;
}









